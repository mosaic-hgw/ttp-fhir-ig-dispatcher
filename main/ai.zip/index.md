# Implementation Guide Workflow-basierte Schnittstellen - v2025.2.0

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2025.2.0 - ci-build  

* [**Table of Contents**](toc.md)
* **Implementation Guide Workflow-basierte Schnittstellen**

## Implementation Guide Workflow-basierte Schnittstellen

| | |
| :--- | :--- |
| *Official URL*:https://ths-greifswald.de/fhir/dispatcher/ImplementationGuide/ths-greifswald.ttp-fhir-gw.dispatcher | *Version*:2025.2.0 |
| Active as of 2026-07-23 | *Computable Name*:IGTTPFHIRGatewayWorkflowbasierteSchnittstellen |

# FHIR-Support für Workflow-basierte Schnittstellen

Stand 18.02.2026

Die Softwarelösungen E-PIX, gPAS, gICS und Dispatcher werden in zahlreichen Forschungseinrichtungen und Projekten für die Realisierung von Treuhandstellen-Services (THS) eingesetzt. Um die Verwendung dieser Lösungen in FHIR-basierten Infrastrukturen zu unterstützen, werden ausgewählte THS-Funktionalitäten durch FHIR-basierte Operations, Profile, Erweiterungen und Terminologien realisiert.

Diese werden in entsprechenden [Implementierungsleitfäden](https://www.ths-greifswald.de/fhir) themenspezifisch beschrieben und zahlreiche Details erläutert.

Der vorliegende **Implementation Guide Workflow-basierte Schnittstellen** setzt den Fokus auf Operations, Profile und Extensions, die für die [föderierte Treuhandstelle (fTTP)](https://www.ths-greifswald.de/dispatcher/fhir) relevant sind.

### Endpunkt

Der FHIR-Endpunkt (`base`) für die workflow-basierte Schnittstelle lautet

**`http[s]://\<host\>:\<port\>/ttp-fhir/fhir/dispatcher`**

Die Umsetzung komplexer Standort- und System-übergreifender Workflows erfordert wohldefinierte Schnittstellen. Im Kontext des **föderierten Record Linkage mittels fTTP** werden unterschiedliche HL7-FHIR Operations genutzt.

### Übersicht der fTTP-Operations

Nachfolgende Tabelle listet die zum aktuellen Zeitpunkt gültigen **fTTP**-Funktionalitäten ([federated Trusted Third Party](https://www.ths-greifswald.de/forscher/num/fttp-fact-sheet)).

| | |
| :--- | :--- |
| [requestPsnWorkflow](OperationDefinition-RequestPsnWorkflow.md) | Wahrscheinlichkeit |
| [requestPsnFromBfWorkflow](OperationDefinition-RequestPsnFromBfWorkflow.md) | Wahrscheinlichkeit |
| [updateBf](OperationDefinition-UpdateBf.md) | Wahrscheinlichkeit |
| [requestTasks](OperationDefinition-RequestTasks.md) | Wahrscheinlichkeit/Clearing |
| [providePatientData](OperationDefinition-ProvidePatientData.md) | Clearing |

### Übersicht der generalisierten fTTP-Operations

| | |
| :--- | :--- |
| [pseudonymizePatient](OperationDefinition-PseudonymizePatient.md) | Erzeugung von Pseudonym(en) für eine Patient-Ressource |

### Package

Das automatisch erzeugte Package (TGZ) steht als Download zur Verfügung unter: [Link](package.tgz).

### Implementierung

Peter Penndorf, Martin Bialke, Christoper Hampf, Frank Michael Moser

### Autoren

Martin Bialke, Stefan Lang

### Kontakt

kontakt-ths (at) med.uni-greifswald.de

