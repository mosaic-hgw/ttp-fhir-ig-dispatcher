# Implementation Guide Übergreifende Schnittstellen - v2025.2.0

