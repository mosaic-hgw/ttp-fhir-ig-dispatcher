# Implementation Guide Workflow-basierte Schnittstellen - v2025.2.0

