# Parameters-RequestPsnFromBfWorkflow-request-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-RequestPsnFromBfWorkflow-request-example-1",
  "parameter" : [
    {
      "name" : "study",
      "valueString" : "mii"
    },
    {
      "name" : "bloomfilter",
      "valueBase64Binary" : "SWNoIGJpbiBlaW4gQmxvb21maWx0ZXIuIFZlcnNwcm9jaGVuLg=="
    },
    {
      "name" : "target",
      "valueString" : "dic_muenster"
    }
  ]
}

```
