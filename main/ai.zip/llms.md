# ths-greifswald.ttp-fhir-gw.dispatcher#2025.2.0: null

## Pages

* [Implementation Guide Workflow-basierte Schnittstellen](index.md)
* [Artifacts Summary](artifacts.md)
* [Terminologie](Terminologie.md)
* [Allgemein](Allgemein.md)

## Resources

### CodeSystems

* [BloomfilterType](CodeSystem-BloomfilterTypeCS.md)

### Resource Profiles

* [IDAT](StructureDefinition-Idat.md)

### ImplementationGuides

* [IGTTPFHIRGatewayWorkflowbasierteSchnittstellen](index.md)

### OperationDefinitions

* [providePatientData](OperationDefinition-ProvidePatientData.md)
* [pseudonymizePatient](OperationDefinition-PseudonymizePatient.md)
* [requestPsnFromBfWorkflow](OperationDefinition-RequestPsnFromBfWorkflow.md)
* [requestPsnWorkflow](OperationDefinition-RequestPsnWorkflow.md)
* [requestTasks](OperationDefinition-RequestTasks.md)
* [updateBf](OperationDefinition-UpdateBf.md)

### Examples

* [PseudonymizePatient-Bundle-request-example-1 (Bundle)](Bundle-PseudonymizePatient-Bundle-request-example-1.md)
* [PseudonymizePatient-Bundle-response-example-1 (Bundle)](Bundle-PseudonymizePatient-Bundle-response-example-1.md)
* [OperationOutcome-UpdateBf-response-example-1 (OperationOutcome)](OperationOutcome-OperationOutcome-UpdateBf-response-example-1.md)
* [Parameters-ProvidePatientData-request-example-1 (Parameters)](Parameters-Parameters-ProvidePatientData-request-example-1.md)
* [Parameters-RequestPsnFromBfWorkflow-request-example-1 (Parameters)](Parameters-Parameters-RequestPsnFromBfWorkflow-request-example-1.md)
* [Parameters-RequestPsnFromBfWorkflow-response-example-1 (Parameters)](Parameters-Parameters-RequestPsnFromBfWorkflow-response-example-1.md)
* [Parameters-RequestPsnWorkflow-request-example-1 (Parameters)](Parameters-Parameters-RequestPsnWorkflow-request-example-1.md)
* [Parameters-RequestPsnWorkflow-response-example-1 (Parameters)](Parameters-Parameters-RequestPsnWorkflow-response-example-1.md)
* [Parameters-RequestTasks-request-example-1 (Parameters)](Parameters-Parameters-RequestTasks-request-example-1.md)
* [Parameters-RequestTasks-response-example-1 (Parameters)](Parameters-Parameters-RequestTasks-response-example-1.md)
* [Parameters-UpdateBf-request-example-1 (Parameters)](Parameters-Parameters-UpdateBf-request-example-1.md)
* [Idat-example-1 (Patient)](Patient-Idat-example-1.md)
