# Parameters-ProvidePatientData-request-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-ProvidePatientData-request-example-1",
  "parameter" : [
    {
      "name" : "taskId",
      "valueId" : "064ddebf-b20e-468a-97fd-88097bcdbc11"
    },
    {
      "name" : "target",
      "valueString" : "eyematics"
    },
    {
      "name" : "patient",
      "resource" : {
        "resourceType" : "Patient",
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/StructureDefinition/patient-birthPlace",
            "valueAddress" : {
              "city" : "Musterhausen"
            }
          }
        ],
        "name" : [
          {
            "family" : "Mustermann",
            "given" : ["Martin"],
            "prefix" : ["Dr. med."],
            "_prefix" : [
              {
                "extension" : [
                  {
                    "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
                    "valueCode" : "AC"
                  }
                ]
              }
            ]
          }
        ],
        "gender" : "male",
        "birthDate" : "1965-12-03"
      }
    }
  ]
}

```
