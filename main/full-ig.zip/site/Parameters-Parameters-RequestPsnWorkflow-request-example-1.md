# Parameters-RequestPsnWorkflow-request-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-RequestPsnWorkflow-request-example-1",
  "parameter" : [
    {
      "name" : "study",
      "valueString" : "mii"
    },
    {
      "name" : "original",
      "valueString" : "dic_1H51T"
    },
    {
      "name" : "source",
      "valueString" : "dic_muenster"
    },
    {
      "name" : "target",
      "valueString" : "eyematics"
    },
    {
      "name" : "event",
      "valueString" : "fttp.getMiiPsn_eyematics"
    }
  ]
}

```
