# requestPsnWorkflow - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "RequestPsnWorkflow",
  "url" : "https://ths-greifswald.de/fhir/OperationDefinition/dispatcher/requestPsnWorkflow",
  "version" : "2025.2.0",
  "name" : "RequestPsnWorkflow",
  "title" : "requestPsnWorkflow",
  "status" : "active",
  "kind" : "operation",
  "date" : "2026-02-18",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [
    {
      "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.ths-greifswald.de/"
        }
      ]
    }
  ],
  "description" : "Abfragen bzw. anlegen von Pseudonymen auf Basis eines vorkonfigurierten Pseudonymisierungsablaufs (Workflow) für einen gegebenen Geltungsbereich (Studie und Standort). Die Rückgabe der generierten standort- und studienspezifischen-Pseudonyme erfolgt als Parameter.",
  "code" : "requestPsnWorkflow",
  "comment" : "Abfragen bzw. anlegen von Pseudonymen auf Basis eines vorkonfigurierten Pseudonymisierungsablaufs (Workflow) für einen gegebenen Geltungsbereich (Studie und Standort). Die Rückgabe der generierten standort- und studienspezifischen-Pseudonyme erfolgt als Parameter.",
  "system" : true,
  "type" : false,
  "instance" : false,
  "parameter" : [
    {
      "name" : "original",
      "use" : "in",
      "min" : 1,
      "max" : "*",
      "documentation" : "Liste studien- und standortspezifischer Originalwerte für die entsprechende Pseudonyme ermittelt bzw. erstellt werden.",
      "type" : "string"
    },
    {
      "name" : "study",
      "use" : "in",
      "min" : 1,
      "max" : "1",
      "documentation" : "Angabe der Studie",
      "type" : "string"
    },
    {
      "name" : "source",
      "use" : "in",
      "min" : 1,
      "max" : "1",
      "documentation" : "Angabe der Quell-Domäne (Herkunft des Originalwertes)",
      "type" : "string"
    },
    {
      "name" : "target",
      "use" : "in",
      "min" : 1,
      "max" : "1",
      "documentation" : "Angabe der Ziel-Domäne",
      "type" : "string"
    },
    {
      "name" : "event",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "Optionaler Parameter. Auszulösendes, vorkonfiguriertes Pseudonymisierungsevents innerhalb des Workflow-Managers.",
      "type" : "string"
    },
    {
      "name" : "pseudonym",
      "use" : "out",
      "min" : 0,
      "max" : "*",
      "documentation" : "Ermitteltes bzw. generiertes studien- und standort-spezifisches Pseudonym",
      "part" : [
        {
          "name" : "original",
          "use" : "out",
          "min" : 1,
          "max" : "1",
          "documentation" : "der zu pseudonymisierende Wert (im Request übergeben)",
          "type" : "Identifier"
        },
        {
          "name" : "target",
          "use" : "out",
          "min" : 1,
          "max" : "1",
          "documentation" : "die verwendete Ziel-Domäne (im Request übergeben)",
          "type" : "Identifier"
        },
        {
          "name" : "pseudonym",
          "use" : "out",
          "min" : 1,
          "max" : "1",
          "documentation" : "das in der Ziel-Domäne erzeugte Pseudonym.",
          "type" : "Identifier"
        }
      ]
    },
    {
      "name" : "error",
      "use" : "out",
      "min" : 0,
      "max" : "*",
      "documentation" : "Wenn einzelne übergebene Parameter fehlerhaft bzw. nicht valide sind, wird statt eines Pseudonyms ein Fehler-Parameter (error-Parameter) mit der Fehlerbeschreibung zurückgeliefert.",
      "part" : [
        {
          "name" : "original",
          "use" : "out",
          "min" : 0,
          "max" : "1",
          "documentation" : "der zu pseudonymisierende Wert (im Request übergeben)",
          "type" : "Identifier"
        },
        {
          "name" : "target",
          "use" : "out",
          "min" : 0,
          "max" : "1",
          "documentation" : "die verwendete Ziel-Domäne (im Request übergeben)",
          "type" : "Identifier"
        },
        {
          "name" : "error-code",
          "use" : "out",
          "min" : 1,
          "max" : "1",
          "documentation" : "Fehlercode",
          "type" : "Coding"
        }
      ]
    }
  ]
}

```
