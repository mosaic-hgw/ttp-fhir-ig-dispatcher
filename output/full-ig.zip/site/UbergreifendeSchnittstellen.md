# Übergreifende Schnittstellen - v2025.1.0

