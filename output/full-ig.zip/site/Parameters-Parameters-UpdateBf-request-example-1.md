# Parameters-UpdateBf-request-example-1 - v2025.1.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-UpdateBf-request-example-1",
  "parameter" : [
    {
      "name" : "study",
      "valueString" : "mii"
    },
    {
      "name" : "bloomfilter",
      "valueBase64Binary" : "SWNoIGJpbiBlaW4gQmxvb21maWx0ZXIuIFZlcnNwcm9jaGVuLg=="
    },
    {
      "name" : "source",
      "valueString" : "dic_muenster"
    },
    {
      "name" : "pseudonym",
      "valueString" : "dic_2Q42E"
    },
    {
      "name" : "bfVersion",
      "valueString" : "2"
    }
  ]
}

```
